package com.obbs.junit;

public class TestJunit {

}
