package com.obbs.model;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Range;

//This Pojo is used to process the requirement data inserted by the recipient during process.
public class PostBloodRequirementPojo {
	private int id;

	@Pattern(regexp = "^[ A-Za-z]+$", message = "Name should not contain numbers")
	@Size(min = 3, max = 50, message = "Name should be between 3 and 50 characters")
	private String requisterName;

	@Range(min = 1000000000, message = "Contact number must be 10 digits")
	private long contactNumber;

	private String state;
	private String area;

	@Range(min = 100000, max = 999999, message = "Pincode must be 6 digits")
	private int pinCode;
	private String bloodGroup;
	private String hospitalName;
	@Email
	private String userMailID;

	private String date;
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getUserMailID() {
		return userMailID;
	}

	public void setUserMailID(String userMailID) {
		this.userMailID = userMailID;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRequisterName() {
		return requisterName;
	}

	public void setRequisterName(String requisterName) {
		this.requisterName = requisterName;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

}
